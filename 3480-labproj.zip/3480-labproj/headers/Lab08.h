#pragma once

#include "Assignment.h"

#include "GPU.h"

class FinalProject : public Assignment {
public:
	Shader shader;

	Camera camera;
	Lighting light;

	std::vector<SceneObject> sceneObjects;

	FinalProject() : Assignment("Final Project", true) { }
	virtual ~FinalProject() { }

	virtual void init();
	virtual void render(s_ptr<Framebuffer> framebuffer);
	virtual void renderUI();

	void addSceneObject() {
		SceneObject newObject;
		newObject.name = fmt::format("Object {0}", sceneObjects.size() + 1);
		sceneObjects.push_back(newObject);
	}
};
